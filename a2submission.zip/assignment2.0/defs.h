#ifndef DEFS_H
#define DEFS_H

#define MAX_VIDS 100
#define MAX_CHANNELS 100



#endif
